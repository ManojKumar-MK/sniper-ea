@echo off
setlocal
REM ===================================================================
REM  FINAL combination grid - the two winners put together.
REM
REM    window  03-13 server  (IST 05:30-15:30)   from the window grid
REM    filter  VWAP + struct                     from the filter grid
REM    spread  40 instead of 70                  free improvement
REM
REM  18 sets x 3 timeframes = 54 runs, Jan-Sep, about 45 minutes.
REM
REM  The eight struct values (0.20 to 0.60) exist to answer one
REM  question: is 0.30 a real optimum with a slope either side, or a
REM  lone spike that happened to suit this data? Read the SHAPE, not
REM  the single best row.
REM
REM  REF_w311_vwap_sp70 is what you run today - the like-for-like
REM  comparison. REF_w313_nofilter is the new window with no filter.
REM
REM  Resumable.
REM ===================================================================
set EXPERT=SniperEntry_Strict_SessionFilter_Telegram_v1.30.ex5
set OPTS=--skip-done --symbol XAUUSD --from 2026.01.01 --to 2026.09.18 --expert "%EXPERT%"

echo. & echo ===== FINAL grid, M15 =====
python run_backtests.py --sets sets_fin --out results_fin_M15 --period M15 %OPTS%
echo. & echo ===== FINAL grid, M5 =====
python run_backtests.py --sets sets_fin --out results_fin_M5  --period M5  %OPTS%
echo. & echo ===== FINAL grid, M3 =====
python run_backtests.py --sets sets_fin --out results_fin_M3  --period M3  %OPTS%

echo.
python run_backtests.py --merge-all
echo. & echo ===== done - send all_results.csv =====
pause
