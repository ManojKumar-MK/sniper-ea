@echo off
setlocal
set MT5DIR=C:\MT5-Tester
if not exist one mkdir one
copy /Y sets_fin\F_w313_struct0p30.set one\ >nul
python run_backtests.py --sets one --out results_smoke --symbol XAUUSD ^
    --period M15 --from 2026.09.01 --to 2026.09.18 --allow-running --debug-report ^
    --expert "SniperEntry_Strict_SessionFilter_Telegram_v1.30.ex5" ^
    --terminal "%MT5DIR%\terminal64.exe" --data-dir "%MT5DIR%"
echo.
echo If a table with a trade count appeared, run RUN_FINAL_PORTABLE.bat
pause
