@echo off
setlocal
REM ===================================================================
REM  FINAL grid - against a SEPARATE PORTABLE MT5, so your live
REM  terminal keeps running untouched.
REM
REM  Set up once:
REM    1. Install a second MT5 to C:\MT5-Tester (not the default path)
REM    2. Shortcut with /portable appended:
REM         "C:\MT5-Tester\terminal64.exe" /portable
REM    3. Launch it, log in, copy the .ex5 into
REM         C:\MT5-Tester\MQL5\Experts\
REM    4. Open an XAUUSD M3 chart there and scroll back past 1 Jan so
REM       it downloads the history
REM    5. Close that terminal. Leave your LIVE one running.
REM
REM  In portable mode the data folder IS the install folder, which is
REM  why --data-dir points at C:\MT5-Tester and not AppData.
REM
REM  --allow-running is required: the guard sees your live terminal and
REM  would otherwise refuse. It is safe here - the two installations are
REM  separate processes with separate data folders.
REM
REM  If you installed somewhere else, change MT5DIR below.
REM ===================================================================

set MT5DIR=C:\MT5-Tester
set EXPERT=SniperEntry_Strict_SessionFilter_Telegram_v1.30.ex5
set OPTS=--skip-done --allow-running --symbol XAUUSD --from 2026.01.01 --to 2026.09.18 ^
 --expert "%EXPERT%" --terminal "%MT5DIR%\terminal64.exe" --data-dir "%MT5DIR%"

if not exist "%MT5DIR%\terminal64.exe" (
  echo.
  echo   Cannot find %MT5DIR%\terminal64.exe
  echo   Install the second MT5 there, or edit MT5DIR at the top of this file.
  echo.
  pause
  exit /b 1
)

echo.
echo   Tester terminal : %MT5DIR%\terminal64.exe
echo   Your LIVE terminal is not touched.
echo.

echo ===== FINAL grid, M15 =====
python run_backtests.py --sets sets_fin --out results_fin_M15 --period M15 %OPTS%
echo. & echo ===== FINAL grid, M5 =====
python run_backtests.py --sets sets_fin --out results_fin_M5  --period M5  %OPTS%
echo. & echo ===== FINAL grid, M3 =====
python run_backtests.py --sets sets_fin --out results_fin_M3  --period M3  %OPTS%

echo.
python run_backtests.py --merge-all
echo. & echo ===== done - send all_results.csv =====
pause
